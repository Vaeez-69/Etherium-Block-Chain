const Image = artifacts.require("Image");

module.exports = function (deployer) {
  deployer.deploy(Image);
};
